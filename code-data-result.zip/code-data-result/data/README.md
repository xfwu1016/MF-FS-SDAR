# AI4I 2020 data

`ai4i2020.csv` is the released AI4I 2020 Predictive Maintenance Dataset obtained
from the UCI Machine Learning Repository (dataset 601).

- Source: https://archive.ics.uci.edu/dataset/601/ai4i+2020+predictive+maintenance+dataset
- Dataset DOI: https://doi.org/10.24432/C5HS5C
- License: Creative Commons Attribution 4.0 International (CC BY 4.0)
- SHA-256: `DC6630CD9B1F0F853922FAD78A1B6436570D3F1EC863F1DD5C4340AC56BC8A8E`

The file is included for reproducibility under the stated license. The dataset
itself is a synthetic industrial-style benchmark released by UCI; in the paper
we refer to this analysis as the application to the released UCI observations,
not as operational plant data.
