#!/usr/bin/env python3
"""Reproduce the numerical material for the AMM submission.

The default mode runs a compact verification suite. Use --full to reproduce
all Monte Carlo tables reported in the manuscript. The suite includes both an
AI4I-inspired synthetic predictive-maintenance benchmark and a separate
application to the released UCI AI4I records; neither is described as an
operational plant data set.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import math
import os
import time
from concurrent.futures import ProcessPoolExecutor, ThreadPoolExecutor
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from numpy.linalg import eigvalsh, norm
from sklearn.discriminant_analysis import LinearDiscriminantAnalysis, QuadraticDiscriminantAnalysis
from sklearn.ensemble import RandomForestClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (
    accuracy_score,
    average_precision_score,
    balanced_accuracy_score,
    confusion_matrix,
    f1_score,
    precision_score,
    recall_score,
    roc_auc_score,
)
from sklearn.neural_network import MLPClassifier
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.svm import SVC
from threadpoolctl import threadpool_limits



# Globals used by the process-based distributed-memory benchmark.  Each worker
# keeps read-only covariance matrices locally; the coordinator broadcasts the
# current multiplier and receives one matrix contribution per block.
_DIST_S1: np.ndarray | None = None
_DIST_S2: np.ndarray | None = None
_DIST_THREAD_LIMIT = None


def _distributed_worker_init(S1: np.ndarray, S2: np.ndarray) -> None:
    global _DIST_S1, _DIST_S2, _DIST_THREAD_LIMIT
    _DIST_S1 = S1
    _DIST_S2 = S2
    _DIST_THREAD_LIMIT = threadpool_limits(limits=1)
    _DIST_THREAD_LIMIT.__enter__()


def _distributed_block_step(payload):
    Db, J, U, eta = payload
    assert _DIST_S1 is not None and _DIST_S2 is not None
    t0 = time.perf_counter()
    S1U, S2U = _DIST_S1 @ U, _DIST_S2 @ U
    grad = 0.5 * (S1U @ _DIST_S2[:, J] + S2U @ _DIST_S1[:, J])
    Dn = soft(Db + grad / eta, 1.0 / eta)
    part = 0.5 * (_DIST_S1 @ Dn @ _DIST_S2[J, :] + _DIST_S2 @ Dn @ _DIST_S1[J, :])
    return Dn, part, time.perf_counter() - t0

ROOT = Path(__file__).resolve().parents[1]
RESULTS = ROOT / "results"
FIGURES = ROOT / "figures"
DATA = ROOT / "data"
RESULTS.mkdir(parents=True, exist_ok=True)
FIGURES.mkdir(parents=True, exist_ok=True)


def soft(x: np.ndarray, threshold: float) -> np.ndarray:
    return np.sign(x) * np.maximum(np.abs(x) - threshold, 0.0)


def proj_inf(x: np.ndarray, radius: float) -> np.ndarray:
    return np.clip(x, -radius, radius)


def op_L(D: np.ndarray, S1: np.ndarray, S2: np.ndarray) -> np.ndarray:
    return 0.5 * (S1 @ D @ S2 + S2 @ D @ S1)


def estimate_L_norm_sq(S1: np.ndarray, S2: np.ndarray, iterations: int = 30, seed: int = 0) -> float:
    """Matrix-free power iteration for ||L||_op^2; L is self-adjoint."""
    rng = np.random.default_rng(seed)
    X = rng.normal(size=S1.shape)
    X /= norm(X, "fro")
    for _ in range(iterations):
        Y = op_L(op_L(X, S1, S2), S1, S2)
        ny = norm(Y, "fro")
        if ny == 0:
            return 0.0
        X = Y / ny
    Y = op_L(op_L(X, S1, S2), S1, S2)
    return float(np.sum(X * Y))


def matrix_ppa(
    S1: np.ndarray,
    S2: np.ndarray,
    B: np.ndarray,
    lam: float,
    mu: float = 1.0,
    max_iter: int = 1500,
    tol: float = 5e-4,
    eta: float | None = None,
    store_every: int = 1,
):
    p = S1.shape[0]
    D = np.zeros((p, p))
    Z = np.zeros((p, p))
    U = np.zeros((p, p))
    if eta is None:
        eta = mu * estimate_L_norm_sq(S1, S2) + 1e-3
    r_prev = op_L(D, S1, S2) - Z - B
    hist: list[tuple[int, float, float, float]] = []
    for t in range(max_iter):
        Dn = soft(D + op_L(U, S1, S2) / eta, 1.0 / eta)
        Zn = proj_inf(Z - U / mu, lam)
        r = op_L(Dn, S1, S2) - Zn - B
        Un = U - (mu / 2.0) * (2.0 * r - r_prev)
        if t % store_every == 0:
            step = math.sqrt(norm(Dn - D, "fro") ** 2 + norm(Zn - Z, "fro") ** 2 + norm(Un - U, "fro") ** 2)
            feasibility = max(0.0, float(np.max(np.abs(op_L(Dn, S1, S2) - B))) - lam)
            hist.append((t + 1, step, feasibility, float(np.sum(np.abs(Dn)))))
            if step < tol and feasibility < tol:
                D, Z, U = Dn, Zn, Un
                break
        D, Z, U, r_prev = Dn, Zn, Un, r
    return D, hist, float(eta)


def vector_ppa(
    A: np.ndarray,
    b: np.ndarray,
    lam: float,
    mu: float = 1.0,
    max_iter: int = 1500,
    tol: float = 5e-4,
    eta: float | None = None,
):
    beta = np.zeros(A.shape[1])
    z = np.zeros(A.shape[0])
    u = np.zeros(A.shape[0])
    if eta is None:
        eta = mu * norm(A, 2) ** 2 + 1e-3
    r_prev = A @ beta - z - b
    hist: list[tuple[int, float, float, float]] = []
    for t in range(max_iter):
        bn = soft(beta + A.T @ u / eta, 1.0 / eta)
        zn = proj_inf(z - u / mu, lam)
        r = A @ bn - zn - b
        un = u - (mu / 2.0) * (2.0 * r - r_prev)
        step = math.sqrt(norm(bn - beta) ** 2 + norm(zn - z) ** 2 + norm(un - u) ** 2)
        feasibility = max(0.0, float(np.max(np.abs(A @ bn - b))) - lam)
        hist.append((t + 1, step, feasibility, float(np.sum(np.abs(bn)))))
        beta, z, u, r_prev = bn, zn, un, r
        if step < tol and feasibility < tol:
            break
    return beta, hist, float(eta)


def fit_sdar(X1: np.ndarray, X2: np.ndarray, cD: float = 2.0, cB: float = 1.5, tol: float = 5e-4, max_iter: int = 1500):
    n = min(len(X1), len(X2))
    p = X1.shape[1]
    m1, m2 = X1.mean(0), X2.mean(0)
    S1 = np.cov(X1, rowvar=False, bias=True)
    S2 = np.cov(X2, rowvar=False, bias=True)
    lamD = cD * math.sqrt(math.log(p) / n)
    lamB = cB * math.sqrt(math.log(p) / n)
    t0 = time.perf_counter()
    D, hD, etaD = matrix_ppa(S1, S2, S1 - S2, lamD, max_iter=max_iter, tol=tol)
    D = 0.5 * (D + D.T)
    tD = time.perf_counter() - t0
    t0 = time.perf_counter()
    beta, hB, etaB = vector_ppa(S2, m2 - m1, lamB, max_iter=max_iter, tol=tol)
    tB = time.perf_counter() - t0
    return {
        "D": D,
        "beta": beta,
        "m1": m1,
        "m2": m2,
        "S1": S1,
        "S2": S2,
        "lamD": lamD,
        "lamB": lamB,
        "hD": hD,
        "hB": hB,
        "etaD": etaD,
        "etaB": etaB,
        "tD": tD,
        "tB": tB,
    }


def sdar_score(fit: dict, X: np.ndarray) -> np.ndarray:
    D, beta = fit["D"], fit["beta"]
    m1, m2, S1 = fit["m1"], fit["m2"], fit["S1"]
    midpoint = 0.5 * (m1 + m2)
    D = 0.5 * (D + D.T)
    evals, evecs = np.linalg.eigh(0.5 * (S1 + S1.T))
    sqrt_s1 = (evecs * np.sqrt(np.maximum(evals, 0.0))) @ evecs.T
    similar = np.eye(D.shape[0]) + sqrt_s1 @ D @ sqrt_s1
    similar = 0.5 * (similar + similar.T)
    eigvals = np.linalg.eigvalsh(similar)
    # The population matrix is positive definite.  The floor is used only as
    # a finite-sample numerical safeguard if an approximate iterate leaves
    # the determinant term outside its natural domain.
    logdet = float(np.sum(np.log(np.maximum(eigvals, 1e-10))))
    return np.einsum("bi,ij,bj->b", X - m1, D, X - m1) - 2.0 * (X - midpoint) @ beta - logdet


def predict_sdar(fit: dict, X: np.ndarray) -> np.ndarray:
    return (sdar_score(fit, X) <= 0).astype(int)


def make_model(p: int, seed: int):
    rng = np.random.default_rng(seed)
    O2 = np.eye(p)
    for i in range(p - 1):
        O2[i, i + 1] = O2[i + 1, i] = -0.12
    D = np.zeros((p, p))
    pairs: set[tuple[int, int]] = set()
    while len(pairs) < max(5, p // 4):
        i, j = sorted(rng.choice(p, 2, replace=False))
        pairs.add((int(i), int(j)))
    for i, j in pairs:
        D[i, j] = D[j, i] = rng.choice([-1.0, 1.0]) * 0.12
    for i in rng.choice(p, size=min(max(3, p // 10), p), replace=False):
        D[i, i] += rng.choice([-1.0, 1.0]) * 0.10
    O1 = O2 - D
    while eigvalsh(O1).min() < 0.25:
        D *= 0.8
        O1 = O2 - D
    S1, S2 = np.linalg.inv(O1), np.linalg.inv(O2)
    beta = np.zeros(p)
    idx = rng.choice(p, size=max(5, p // 6), replace=False)
    beta[idx] = rng.choice([-1.0, 1.0], size=len(idx)) * 0.6
    delta = S2 @ beta
    return np.zeros(p), delta, S1, S2, D, beta


def make_cov_only_model(p: int, seed: int):
    rng = np.random.default_rng(seed)
    O2 = np.eye(p)
    D = np.zeros((p, p))
    pairs: set[tuple[int, int]] = set()
    while len(pairs) < max(10, p // 2):
        i, j = sorted(rng.choice(p, 2, replace=False))
        pairs.add((int(i), int(j)))
    for i, j in pairs:
        D[i, j] = D[j, i] = rng.choice([-1.0, 1.0]) * 0.28
    for i in rng.choice(p, size=min(max(8, p // 5), p), replace=False):
        D[i, i] += rng.choice([-1.0, 1.0]) * 0.30
    O1 = O2 - D
    while eigvalsh(O1).min() < 0.15 or eigvalsh(O1).max() > 3.0:
        D *= 0.88
        O1 = O2 - D
    return np.zeros(p), np.zeros(p), np.linalg.inv(O1), np.eye(p), D, np.zeros(p)


def sample_data(n1: int, n2: int, model: tuple, seed: int):
    mu1, mu2, S1, S2, _, _ = model
    rng = np.random.default_rng(seed)
    return rng.multivariate_normal(mu1, S1, size=n1), rng.multivariate_normal(mu2, S2, size=n2)


def evaluate_standard_methods(X1: np.ndarray, X2: np.ndarray, Xt: np.ndarray, yt: np.ndarray, fit: dict):
    Xtr = np.vstack([X1, X2])
    ytr = np.r_[np.zeros(len(X1), dtype=int), np.ones(len(X2), dtype=int)]
    rows = []
    pred = predict_sdar(fit, Xt)
    rows.append(("MF-FS-SDAR", balanced_accuracy_score(yt, pred), accuracy_score(yt, pred), f1_score(yt, pred)))
    methods = [
        ("LDA", LinearDiscriminantAnalysis(solver="lsqr", shrinkage="auto")),
        ("QDA", QuadraticDiscriminantAnalysis(reg_param=0.2)),
        ("Logistic", make_pipeline(StandardScaler(), LogisticRegression(max_iter=3000))),
        ("RBF-SVM", make_pipeline(StandardScaler(), SVC(C=1, gamma="scale"))),
    ]
    for name, clf in methods:
        clf.fit(Xtr, ytr)
        pred = clf.predict(Xt)
        rows.append((name, balanced_accuracy_score(yt, pred), accuracy_score(yt, pred), f1_score(yt, pred)))
    return rows


def run_simulations(full: bool):
    # General scenario: the cached manuscript table was generated with 12 repetitions.
    reps_general = 12 if full else 2
    reps_cov = 8 if full else 2
    general_rows, cov_rows = [], []
    for p in [30, 60, 100]:
        for rep in range(reps_general):
            model = make_model(p, 1000 + 10 * p + rep)
            X1, X2 = sample_data(150, 150, model, 2000 + rep)
            T1, T2 = sample_data(750, 750, model, 3000 + rep)
            Xt = np.vstack([T1, T2])
            yt = np.r_[np.zeros(750, dtype=int), np.ones(750, dtype=int)]
            fit = fit_sdar(X1, X2, cD=2.0, cB=1.5)
            for method, bacc, acc, f1 in evaluate_standard_methods(X1, X2, Xt, yt, fit):
                general_rows.append({"p": p, "rep": rep, "method": method, "balanced_accuracy": bacc, "accuracy": acc, "f1": f1})
    for p in [30, 60, 90]:
        for rep in range(reps_cov):
            model = make_cov_only_model(p, 8000 + 10 * p + rep)
            X1, X2 = sample_data(400, 400, model, 9000 + rep)
            T1, T2 = sample_data(750, 750, model, 10000 + rep)
            Xt = np.vstack([T1, T2])
            yt = np.r_[np.zeros(750, dtype=int), np.ones(750, dtype=int)]
            fit = fit_sdar(X1, X2, cD=1.5, cB=4.0, max_iter=2000)
            for method, bacc, acc, f1 in evaluate_standard_methods(X1, X2, Xt, yt, fit):
                cov_rows.append({"p": p, "rep": rep, "method": method, "balanced_accuracy": bacc, "accuracy": acc, "f1": f1})
    gdf, cdf = pd.DataFrame(general_rows), pd.DataFrame(cov_rows)
    gdf.to_csv(RESULTS / "simulation_general_raw.csv", index=False)
    cdf.to_csv(RESULTS / "simulation_covariance_only_raw.csv", index=False)
    gsum = gdf.groupby(["p", "method"], as_index=False).agg(mean_balanced_accuracy=("balanced_accuracy", "mean"), sd_balanced_accuracy=("balanced_accuracy", "std"))
    csum = cdf.groupby(["p", "method"], as_index=False).agg(mean_balanced_accuracy=("balanced_accuracy", "mean"), sd_balanced_accuracy=("balanced_accuracy", "std"))
    gsum.to_csv(RESULTS / "simulation_general_summary.csv", index=False)
    csum.to_csv(RESULTS / "simulation_covariance_only_summary.csv", index=False)
    return gsum, csum


def split_indices(p: int, K: int, seed: int = 0, random_split: bool = True):
    idx = np.arange(p)
    if random_split:
        np.random.default_rng(seed).shuffle(idx)
    return [np.asarray(a, dtype=int) for a in np.array_split(idx, K)]


def matrix_ppa_split(S1, S2, B, lam, K=4, mu=1.0, max_iter=300, tol=0.0, eta=None, seed=0, parallel=False):
    p = S1.shape[0]
    blocks = split_indices(p, K, seed)
    D_blocks = [np.zeros((p, len(J))) for J in blocks]
    Z, U = np.zeros((p, p)), np.zeros((p, p))
    eta = eta if eta is not None else mu * estimate_L_norm_sq(S1, S2) + 1e-3
    D = np.zeros((p, p))
    r_prev = op_L(D, S1, S2) - Z - B
    hist = []
    for t in range(max_iter):
        S1U, S2U = S1 @ U, S2 @ U

        def update(pair):
            Db, J = pair
            grad = 0.5 * (S1U @ S2[:, J] + S2U @ S1[:, J])
            return soft(Db + grad / eta, 1.0 / eta)

        if parallel and K > 1:
            with ThreadPoolExecutor(max_workers=K) as executor:
                Dn_blocks = list(executor.map(update, zip(D_blocks, blocks)))
        else:
            Dn_blocks = [update(x) for x in zip(D_blocks, blocks)]

        def forward(pair):
            Db, J = pair
            return 0.5 * (S1 @ Db @ S2[J, :] + S2 @ Db @ S1[J, :])

        if parallel and K > 1:
            with ThreadPoolExecutor(max_workers=K) as executor:
                parts = list(executor.map(forward, zip(Dn_blocks, blocks)))
        else:
            parts = [forward(x) for x in zip(Dn_blocks, blocks)]
        LD = sum(parts)
        Zn = proj_inf(Z - U / mu, lam)
        r = LD - Zn - B
        Un = U - (mu / 2.0) * (2.0 * r - r_prev)
        Dn = np.zeros((p, p))
        for Db, J in zip(Dn_blocks, blocks):
            Dn[:, J] = Db
        step = math.sqrt(norm(Dn - D, "fro") ** 2 + norm(Zn - Z, "fro") ** 2 + norm(Un - U, "fro") ** 2)
        hist.append((t + 1, step))
        D_blocks, Z, U, D, r_prev = Dn_blocks, Zn, Un, Dn, r
        if step < tol:
            break
    return D, hist


def run_partition_test():
    p = 40
    model = make_model(p, 123)
    X1, X2 = sample_data(180, 180, model, 321)
    S1 = np.cov(X1, rowvar=False, bias=True)
    S2 = np.cov(X2, rowvar=False, bias=True)
    B = S1 - S2
    lam = 2.0 * math.sqrt(math.log(p) / 180)
    eta = estimate_L_norm_sq(S1, S2) + 1e-3
    D1, _, _ = matrix_ppa(S1, S2, B, lam, eta=eta, max_iter=300, tol=0.0)
    rows = [{"K": 1, "max_abs_difference": 0.0}]
    for K in [2, 4, 5, 8]:
        DK, _ = matrix_ppa_split(S1, S2, B, lam, K=K, eta=eta, max_iter=300, seed=K)
        rows.append({"K": K, "max_abs_difference": float(np.max(np.abs(DK - D1)))})
    pd.DataFrame(rows).to_csv(RESULTS / "partition_insensitivity.csv", index=False)
    return pd.DataFrame(rows)


def random_spd(p: int, seed: int):
    rng = np.random.default_rng(seed)
    A = 1.3 * np.eye(p)
    for k in [1, 2, 3]:
        vals = rng.uniform(-0.05, 0.05, size=p - k)
        A[np.arange(p - k), np.arange(k, p)] = vals
        A[np.arange(k, p), np.arange(p - k)] = vals
    return A


def run_microbenchmark(full: bool):
    p = 700 if full else 250
    iterations = 5 if full else 3
    S1, S2 = random_spd(p, 1), random_spd(p, 2)
    B, lam = S1 - S2, 0.05
    eta = estimate_L_norm_sq(S1, S2, iterations=10) + 1e-3
    rows = []
    with threadpool_limits(limits=1):
        for K in [1, 2, 4, 8]:
            matrix_ppa_split(S1, S2, B, lam, K=K, eta=eta, max_iter=1, parallel=K > 1)
            times = []
            for _ in range(3):
                t0 = time.perf_counter()
                matrix_ppa_split(S1, S2, B, lam, K=K, eta=eta, max_iter=iterations, parallel=K > 1)
                times.append(time.perf_counter() - t0)
            rows.append({"K": K, "median_seconds": float(np.median(times)), "sd_seconds": float(np.std(times))})
    df = pd.DataFrame(rows)
    df["speedup"] = df.loc[df["K"] == 1, "median_seconds"].iloc[0] / df["median_seconds"]
    df.to_csv(RESULTS / "shared_memory_microbenchmark.csv", index=False)
    return df


def matrix_ppa_distributed_process(
    S1: np.ndarray,
    S2: np.ndarray,
    B: np.ndarray,
    lam: float,
    K: int,
    eta: float,
    iterations: int,
    seed: int = 0,
):
    """Process-based distributed-memory emulation with a central all-reduce.

    This routine is intentionally labelled an emulation: workers are separate
    operating-system processes on one host.  It measures serialization,
    broadcast, aggregation and scheduling overhead in addition to local block
    computation, but it is not a multi-node network benchmark.
    """
    p = S1.shape[0]
    blocks = split_indices(p, K, seed)
    D_blocks = [np.zeros((p, len(J))) for J in blocks]
    Z = np.zeros((p, p))
    U = np.zeros((p, p))
    D = np.zeros((p, p))
    r_prev = op_L(D, S1, S2) - Z - B
    compute_times, overhead_times = [], []
    t_total = time.perf_counter()
    with ProcessPoolExecutor(max_workers=K, initializer=_distributed_worker_init, initargs=(S1, S2)) as pool:
        for _ in range(iterations):
            t_iter = time.perf_counter()
            payloads = [(Db, J, U, eta) for Db, J in zip(D_blocks, blocks)]
            outputs = list(pool.map(_distributed_block_step, payloads))
            Dn_blocks = [o[0] for o in outputs]
            parts = [o[1] for o in outputs]
            worker_compute = max(o[2] for o in outputs)
            LD = np.add.reduce(parts)
            Zn = proj_inf(Z - U, lam)
            r = LD - Zn - B
            Un = U - 0.5 * (2.0 * r - r_prev)
            Dn = np.zeros((p, p))
            for Db, J in zip(Dn_blocks, blocks):
                Dn[:, J] = Db
            elapsed = time.perf_counter() - t_iter
            compute_times.append(worker_compute)
            overhead_times.append(max(0.0, elapsed - worker_compute))
            D_blocks, Z, U, D, r_prev = Dn_blocks, Zn, Un, Dn, r
    return D, time.perf_counter() - t_total, float(sum(compute_times)), float(sum(overhead_times))


def run_distributed_benchmark(full: bool):
    p = 420 if full else 240
    iterations = 20 if full else 6
    repeats = 3 if full else 1
    S1, S2 = random_spd(p, 11), random_spd(p, 12)
    B, lam = S1 - S2, 0.01
    eta = estimate_L_norm_sq(S1, S2, iterations=12) + 1e-3
    rows = []
    reference = None
    for K in [1, 2, 4]:
        times, computes, overheads, diffs = [], [], [], []
        for rep in range(repeats):
            D, total, compute, overhead = matrix_ppa_distributed_process(
                S1, S2, B, lam, K=K, eta=eta, iterations=iterations, seed=K
            )
            if K == 1 and reference is None:
                reference = D.copy()
            times.append(total)
            computes.append(compute)
            overheads.append(overhead)
            diffs.append(float(np.max(np.abs(D - reference))) if reference is not None else 0.0)
        rows.append({
            "K": K,
            "median_seconds": float(np.median(times)),
            "median_worker_compute_seconds": float(np.median(computes)),
            "median_communication_aggregation_seconds": float(np.median(times) - np.median(computes)),
            "max_abs_difference_from_K1": float(np.max(diffs)),
            "p": p,
            "iterations": iterations,
            "execution_mode": "single-host process-based distributed-memory emulation",
        })
    df = pd.DataFrame(rows)
    baseline = df.loc[df.K == 1, "median_seconds"].iloc[0]
    df["speedup"] = baseline / df["median_seconds"]
    df["parallel_efficiency"] = df["speedup"] / df["K"]
    df.to_csv(RESULTS / "distributed_process_benchmark.csv", index=False)
    return df


def explicit_kronecker_ppa(
    S1: np.ndarray,
    S2: np.ndarray,
    B: np.ndarray,
    lam: float,
    mu: float = 1.0,
    iterations: int = 10,
):
    """Reference PPA that explicitly materialises the p^2 by p^2 operator.

    This routine is used only for a small-dimensional comparison.  The
    matrix-free algorithm never calls it and therefore never allocates Kmat.
    """
    p = S1.shape[0]
    build_start = time.perf_counter()
    Kmat = 0.5 * (np.kron(S2, S1) + np.kron(S1, S2))
    build_seconds = time.perf_counter() - build_start
    b = B.reshape(-1, order="F")
    d = np.zeros(p * p)
    z = np.zeros(p * p)
    u = np.zeros(p * p)
    eigvals = np.linalg.eigvalsh(Kmat)
    eta = mu * float(np.max(np.abs(eigvals)) ** 2) + 1e-3
    r_prev = Kmat @ d - z - b
    solve_start = time.perf_counter()
    for _ in range(iterations):
        dn = soft(d + Kmat @ u / eta, 1.0 / eta)
        zn = proj_inf(z - u / mu, lam)
        r = Kmat @ dn - zn - b
        un = u - (mu / 2.0) * (2.0 * r - r_prev)
        d, z, u, r_prev = dn, zn, un, r
    solve_seconds = time.perf_counter() - solve_start
    return d.reshape((p, p), order="F"), build_seconds, solve_seconds, int(Kmat.nbytes)


def _memory_accounting(p: int, K: int) -> dict:
    float_bytes = 8
    return {
        "kron_storage_gib": (p ** 4 * float_bytes) / 2**30,
        "matrix_free_core_mib": (6 * p * p * float_bytes) / 2**20,
        "local_block_mib": (p * math.ceil(p / K) * float_bytes) / 2**20,
        "broadcast_plus_return_mib_per_iter": (2 * K * p * p * float_bytes) / 2**20,
    }


def run_solver_comparison(full: bool):
    """Compare explicit Kronecker, unsplit matrix-free and split PPA updates."""
    p_values = [20, 40, 60, 80] if full else [20, 40]
    iterations = 10 if full else 4
    rows = []
    for p in p_values:
        S1, S2 = random_spd(p, 2100 + p), random_spd(p, 2200 + p)
        B, lam = S1 - S2, 0.05
        eta = estimate_L_norm_sq(S1, S2, iterations=20) + 1e-3
        ref = None
        with threadpool_limits(limits=1):
            t0 = time.perf_counter()
            D_full, _, _ = matrix_ppa(S1, S2, B, lam, eta=eta, max_iter=iterations, tol=0.0)
            full_seconds = time.perf_counter() - t0
            ref = D_full
            rows.append({
                "p": p,
                "method": "Unsplit matrix-free PPA",
                "iterations": iterations,
                "total_seconds": full_seconds,
                "kron_storage_gib": 0.0,
                "max_abs_difference_from_unsplit": 0.0,
                **_memory_accounting(p, 1),
            })

            t0 = time.perf_counter()
            D_split, _ = matrix_ppa_split(S1, S2, B, lam, K=4, eta=eta, max_iter=iterations, tol=0.0, seed=4, parallel=True)
            split_seconds = time.perf_counter() - t0
            rows.append({
                "p": p,
                "method": "MF-FS-SDAR (K=4)",
                "iterations": iterations,
                "total_seconds": split_seconds,
                "kron_storage_gib": 0.0,
                "max_abs_difference_from_unsplit": float(np.max(np.abs(D_split - ref))),
                **_memory_accounting(p, 4),
            })

            D_kron, build_seconds, solve_seconds, kron_bytes = explicit_kronecker_ppa(S1, S2, B, lam, iterations=iterations)
            rows.append({
                "p": p,
                "method": "Explicit Kronecker PPA",
                "iterations": iterations,
                "total_seconds": build_seconds + solve_seconds,
                "kron_storage_gib": kron_bytes / 2**30,
                "max_abs_difference_from_unsplit": float(np.max(np.abs(D_kron - ref))),
                **_memory_accounting(p, 1),
                "kron_build_seconds": build_seconds,
                "kron_solve_seconds": solve_seconds,
            })
    df = pd.DataFrame(rows)
    df.to_csv(RESULTS / "solver_comparison.csv", index=False)
    return df


def run_scale_benchmark(full: bool):
    """Measure matrix-free runtime and communication-equivalent payload by p."""
    p_values = [100, 200, 400, 600, 700] if full else [100, 200, 400]
    iterations = 5 if full else 2
    rows = []
    with threadpool_limits(limits=1):
        for p in p_values:
            S1, S2 = random_spd(p, 3100 + p), random_spd(p, 3200 + p)
            B, lam = S1 - S2, 0.05
            eta = estimate_L_norm_sq(S1, S2, iterations=12) + 1e-3
            for K in [1, 4]:
                t0 = time.perf_counter()
                matrix_ppa_split(S1, S2, B, lam, K=K, eta=eta, max_iter=iterations, tol=0.0, seed=K, parallel=K > 1)
                elapsed = time.perf_counter() - t0
                rows.append({
                    "p": p,
                    "K": K,
                    "iterations": iterations,
                    "runtime_seconds": elapsed,
                    **_memory_accounting(p, K),
                })
    df = pd.DataFrame(rows)
    df.to_csv(RESULTS / "scale_benchmark.csv", index=False)
    return df


def generate_ai4i_style(n: int = 10000, seed: int = 7):
    """Synthetic benchmark generator based on documented AI4I failure mechanisms."""
    rng = np.random.default_rng(seed)
    types = rng.choice(np.array(["L", "M", "H"]), size=n, p=[0.5, 0.3, 0.2])
    air = np.cumsum(rng.normal(0, 0.08, size=n))
    air = 300 + 2 * (air - air.mean()) / air.std()
    proc_rw = np.cumsum(rng.normal(0, 0.05, size=n))
    proc_rw = (proc_rw - proc_rw.mean()) / proc_rw.std()
    proc = air + 10 + proc_rw
    torque = np.clip(rng.normal(40, 10, size=n), 3, 80)
    speed = np.clip(1550 - 12 * (torque - 40) + rng.normal(0, 80, size=n), 1100, 2900)
    increments = np.where(types == "L", 2, np.where(types == "M", 3, 5))
    wear = np.empty(n)
    current = 0.0
    for i in range(n):
        wear[i] = current
        current += increments[i]
        if current > 250:
            current = 0.0
    gap = proc - air
    power = torque * speed * 2 * np.pi / 60
    hdf = (gap < 8.6) & (speed < 1380)
    pwf = (power < 3500) | (power > 9000)
    thresholds = np.where(types == "L", 11000, np.where(types == "M", 12000, 13000))
    osf = wear * torque > thresholds
    twf = (wear >= 200) & (wear <= 240) & (rng.random(n) < 0.04)
    rnf = rng.random(n) < 0.001
    failure = twf | hdf | pwf | osf | rnf
    return pd.DataFrame(
        {
            "Type": types,
            "Air temperature [K]": air,
            "Process temperature [K]": proc,
            "Rotational speed [rpm]": speed,
            "Torque [Nm]": torque,
            "Tool wear [min]": wear,
            "Machine failure": failure.astype(int),
            "TWF": twf.astype(int),
            "HDF": hdf.astype(int),
            "PWF": pwf.astype(int),
            "OSF": osf.astype(int),
            "RNF": rnf.astype(int),
        }
    )


def engineer_ai4i(df: pd.DataFrame, max_lag: int = 8):
    out = pd.DataFrame(index=df.index)
    base = ["Air temperature [K]", "Process temperature [K]", "Rotational speed [rpm]", "Torque [Nm]", "Tool wear [min]"]
    names = ["air", "process", "speed", "torque", "wear"]
    for col in base:
        short = col.split(" [")[0].replace(" ", "_")
        for lag in range(max_lag + 1):
            out[f"{short}_lag{lag}"] = df[col].shift(lag)
        out[f"{short}_diff1"] = df[col].diff()
    for name, col in zip(names, base):
        out[f"{name}_sq"] = df[col] ** 2
    for i in range(len(base)):
        for j in range(i + 1, len(base)):
            out[f"{names[i]}_x_{names[j]}"] = df[base[i]] * df[base[j]]
    out["temp_gap"] = df[base[1]] - df[base[0]]
    out["power"] = df[base[3]] * df[base[2]] * 2 * np.pi / 60
    out["wear_torque"] = df[base[4]] * df[base[3]]
    out["type_L"] = (df["Type"] == "L").astype(float)
    out["type_M"] = (df["Type"] == "M").astype(float)
    valid = out.notna().all(axis=1)
    return out.loc[valid].reset_index(drop=True), df.loc[valid, "Machine failure"].reset_index(drop=True)


def tune_threshold_low(scores: np.ndarray, y: np.ndarray):
    best = (-1.0, 0.0)
    for th in np.quantile(scores, np.linspace(0.01, 0.99, 199)):
        value = balanced_accuracy_score(y, (scores <= th).astype(int))
        if value > best[0]:
            best = (value, float(th))
    return best


def eval_classifier(name, clf, Xtrain, ytrain, Xval, yval, Xtest, ytest):
    t0 = time.perf_counter()
    clf.fit(Xtrain, ytrain)
    elapsed = time.perf_counter() - t0
    if hasattr(clf, "predict_proba"):
        sva, ste = clf.predict_proba(Xval)[:, 1], clf.predict_proba(Xtest)[:, 1]
    else:
        sva, ste = clf.decision_function(Xval), clf.decision_function(Xtest)
    best = (-1.0, 0.0)
    for th in np.quantile(sva, np.linspace(0.01, 0.99, 199)):
        value = balanced_accuracy_score(yval, (sva >= th).astype(int))
        if value > best[0]:
            best = (value, float(th))
    pred = (ste >= best[1]).astype(int)
    return {
        "method": name,
        "balanced_accuracy": balanced_accuracy_score(ytest, pred),
        "precision": precision_score(ytest, pred, zero_division=0),
        "recall": recall_score(ytest, pred, zero_division=0),
        "f1": f1_score(ytest, pred, zero_division=0),
        "roc_auc": roc_auc_score(ytest, ste),
        "pr_auc": average_precision_score(ytest, ste),
        "training_seconds": elapsed,
        "threshold": best[1],
        "tn": int(confusion_matrix(ytest, pred)[0, 0]),
        "fp": int(confusion_matrix(ytest, pred)[0, 1]),
        "fn": int(confusion_matrix(ytest, pred)[1, 0]),
        "tp": int(confusion_matrix(ytest, pred)[1, 1]),
    }


def run_digital_twin():
    df = generate_ai4i_style()
    Xdf, y = engineer_ai4i(df)
    n = len(Xdf)
    ntr, nva = int(0.70 * n), int(0.15 * n)
    Xtr0 = Xdf.iloc[:ntr].to_numpy(float)
    Xva0 = Xdf.iloc[ntr : ntr + nva].to_numpy(float)
    Xte0 = Xdf.iloc[ntr + nva :].to_numpy(float)
    ytr = y.iloc[:ntr].to_numpy(int)
    yva = y.iloc[ntr : ntr + nva].to_numpy(int)
    yte = y.iloc[ntr + nva :].to_numpy(int)
    scaler = StandardScaler().fit(Xtr0)
    Xtr, Xva, Xte = scaler.transform(Xtr0), scaler.transform(Xva0), scaler.transform(Xte0)
    rng = np.random.default_rng(123)
    pos, neg = np.where(ytr == 1)[0], np.where(ytr == 0)[0]
    neg_sample = rng.choice(neg, size=len(pos), replace=False)
    balanced = np.r_[neg_sample, pos]
    rng.shuffle(balanced)
    Xb, yb = Xtr[balanced], ytr[balanced]
    X1, X2 = Xb[yb == 0], Xb[yb == 1]

    best = None
    grid_rows = []
    for cD in [1.0, 1.5, 2.0, 2.5]:
        for cB in [1.0, 1.5, 2.0, 2.5, 3.0]:
            fit = fit_sdar(X1, X2, cD=cD, cB=cB, tol=7e-4, max_iter=1800)
            val, th = tune_threshold_low(sdar_score(fit, Xva), yva)
            grid_rows.append({"cD": cD, "cB": cB, "validation_balanced_accuracy": val, "threshold": th})
            if best is None or val > best[0]:
                best = (val, cD, cB, th, fit)
    pd.DataFrame(grid_rows).to_csv(RESULTS / "digital_twin_tuning_grid.csv", index=False)
    _, cD, cB, threshold, fit = best
    scores = sdar_score(fit, Xte)
    pred = (scores <= threshold).astype(int)
    rows = [
        {
            "method": "MF-FS-SDAR",
            "balanced_accuracy": balanced_accuracy_score(yte, pred),
            "precision": precision_score(yte, pred),
            "recall": recall_score(yte, pred),
            "f1": f1_score(yte, pred),
            "roc_auc": roc_auc_score(yte, -scores),
            "pr_auc": average_precision_score(yte, -scores),
            "training_seconds": fit["tD"] + fit["tB"],
            "threshold": threshold,
            "tn": int(confusion_matrix(yte, pred)[0, 0]),
            "fp": int(confusion_matrix(yte, pred)[0, 1]),
            "fn": int(confusion_matrix(yte, pred)[1, 0]),
            "tp": int(confusion_matrix(yte, pred)[1, 1]),
        }
    ]
    rows.append(eval_classifier("Shrinkage LDA", LinearDiscriminantAnalysis(solver="lsqr", shrinkage="auto"), Xb, yb, Xva, yva, Xte, yte))
    best_qda = (-1.0, 0.2)
    for reg in [0.01, 0.05, 0.1, 0.2, 0.4, 0.6]:
        clf = QuadraticDiscriminantAnalysis(reg_param=reg).fit(Xb, yb)
        sva = clf.predict_proba(Xva)[:, 1]
        val = max(balanced_accuracy_score(yva, (sva >= th).astype(int)) for th in np.quantile(sva, np.linspace(0.01, 0.99, 199)))
        if val > best_qda[0]:
            best_qda = (val, reg)
    rows.append(eval_classifier("Regularized QDA", QuadraticDiscriminantAnalysis(reg_param=best_qda[1]), Xb, yb, Xva, yva, Xte, yte))
    rows.append(eval_classifier("Logistic", make_pipeline(StandardScaler(with_mean=False), LogisticRegression(max_iter=5000, class_weight="balanced")), Xtr, ytr, Xva, yva, Xte, yte))
    rows.append(eval_classifier("RBF-SVM", SVC(C=1, gamma="scale", class_weight="balanced", probability=True, random_state=1), Xtr, ytr, Xva, yva, Xte, yte))
    rows.append(eval_classifier("Random forest", RandomForestClassifier(n_estimators=300, class_weight="balanced_subsample", random_state=1, n_jobs=-1, min_samples_leaf=2), Xtr, ytr, Xva, yva, Xte, yte))
    result = pd.DataFrame(rows)
    result.to_csv(RESULTS / "digital_twin_results.csv", index=False)
    metadata = {
        "generator": "AI4I-inspired synthetic predictive-maintenance benchmark; no UCI raw observations are included",
        "n_generated": int(len(df)),
        "n_usable": int(len(Xdf)),
        "p_engineered": int(Xdf.shape[1]),
        "failure_rate": float(y.mean()),
        "train_counts": np.bincount(ytr).tolist(),
        "validation_counts": np.bincount(yva).tolist(),
        "test_counts": np.bincount(yte).tolist(),
        "selected_cD": cD,
        "selected_cB": cB,
    }
    (RESULTS / "digital_twin_metadata.json").write_text(json.dumps(metadata, indent=2), encoding="utf-8")
    # Save convergence histories and a heatmap of the estimated differential graph.
    pd.DataFrame(fit["hD"], columns=["iteration", "step", "feasibility", "l1_norm"]).to_csv(RESULTS / "matrix_convergence.csv", index=False)
    pd.DataFrame(fit["hB"], columns=["iteration", "step", "feasibility", "l1_norm"]).to_csv(RESULTS / "vector_convergence.csv", index=False)
    np.save(RESULTS / "digital_twin_D.npy", fit["D"])
    return result, fit


def run_real_ai4i_application():
    """Run the same protocol on the released UCI AI4I observations."""
    data_file = DATA / "ai4i2020.csv"
    if not data_file.exists():
        raise FileNotFoundError(
            "Missing data/ai4i2020.csv. Download the UCI AI4I 2020 dataset from "
            "https://archive.ics.uci.edu/dataset/601/ai4i+2020+predictive+maintenance+dataset"
        )
    raw = pd.read_csv(data_file)
    Xdf, y = engineer_ai4i(raw)
    n = len(Xdf)
    ntr, nva = int(0.70 * n), int(0.15 * n)
    Xtr0 = Xdf.iloc[:ntr].to_numpy(float)
    Xva0 = Xdf.iloc[ntr:ntr + nva].to_numpy(float)
    Xte0 = Xdf.iloc[ntr + nva:].to_numpy(float)
    ytr = y.iloc[:ntr].to_numpy(int)
    yva = y.iloc[ntr:ntr + nva].to_numpy(int)
    yte = y.iloc[ntr + nva:].to_numpy(int)
    scaler = StandardScaler().fit(Xtr0)
    Xtr, Xva, Xte = scaler.transform(Xtr0), scaler.transform(Xva0), scaler.transform(Xte0)

    rng = np.random.default_rng(123)
    pos, neg = np.where(ytr == 1)[0], np.where(ytr == 0)[0]
    neg_sample = rng.choice(neg, size=len(pos), replace=False)
    balanced = np.r_[neg_sample, pos]
    rng.shuffle(balanced)
    Xb, yb = Xtr[balanced], ytr[balanced]
    X1, X2 = Xb[yb == 0], Xb[yb == 1]

    grid_rows = []
    # Use a wider validation grid than the initial revision.  The validation
    # block contains only 32 failures, so selecting the numerical maximum can
    # be sensitive to one positive-class decision.  We therefore select, after
    # evaluating the full grid, the most regularised candidate within one
    # positive-class balanced-accuracy resolution of the validation maximum.
    cD_grid = [0.5, 1.0, 1.5, 2.0, 2.5, 3.0, 3.5, 4.0, 5.0, 6.0, 8.0]
    cB_grid = [0.25, 0.5, 0.75, 1.0, 1.25, 1.5, 2.0, 2.5, 3.0]
    for cD in cD_grid:
        for cB in cB_grid:
            fit = fit_sdar(X1, X2, cD=cD, cB=cB, tol=7e-4, max_iter=1800)
            val, th = tune_threshold_low(sdar_score(fit, Xva), yva)
            grid_rows.append({"cD": cD, "cB": cB, "validation_balanced_accuracy": val, "threshold": th})
    best_val = max(row["validation_balanced_accuracy"] for row in grid_rows)
    positive_resolution = 1.0 / (2.0 * max(1, int(yva.sum())))
    eligible = [
        row for row in grid_rows
        if row["validation_balanced_accuracy"] >= best_val - positive_resolution
    ]
    selected = max(eligible, key=lambda row: (row["cB"], -row["cD"]))
    for row in grid_rows:
        row["selected"] = row is selected
    tuning = pd.DataFrame(grid_rows)
    tuning.to_csv(RESULTS / "ai4i_real_tuning_grid.csv", index=False)
    cD, cB, threshold = selected["cD"], selected["cB"], selected["threshold"]
    fit = fit_sdar(X1, X2, cD=cD, cB=cB, tol=7e-4, max_iter=1800)

    scores = sdar_score(fit, Xte)
    pred = (scores <= threshold).astype(int)
    cm = confusion_matrix(yte, pred)
    rows = [{
        "method": "MF-FS-SDAR",
        "balanced_accuracy": balanced_accuracy_score(yte, pred),
        "precision": precision_score(yte, pred, zero_division=0),
        "recall": recall_score(yte, pred, zero_division=0),
        "f1": f1_score(yte, pred, zero_division=0),
        "roc_auc": roc_auc_score(yte, -scores),
        "pr_auc": average_precision_score(yte, -scores),
        "training_seconds": fit["tD"] + fit["tB"],
        "threshold": threshold,
        "tn": int(cm[0, 0]), "fp": int(cm[0, 1]), "fn": int(cm[1, 0]), "tp": int(cm[1, 1]),
    }]
    rows.append(eval_classifier("Shrinkage LDA", LinearDiscriminantAnalysis(solver="lsqr", shrinkage="auto"), Xb, yb, Xva, yva, Xte, yte))
    best_qda = (-1.0, 0.2)
    for reg in [0.01, 0.05, 0.1, 0.2, 0.4, 0.6]:
        clf = QuadraticDiscriminantAnalysis(reg_param=reg).fit(Xb, yb)
        sva = clf.predict_proba(Xva)[:, 1]
        for th in np.quantile(sva, np.linspace(0.01, 0.99, 199)):
            val = balanced_accuracy_score(yva, (sva >= th).astype(int))
            if val > best_qda[0]:
                best_qda = (val, reg)
    rows.append(eval_classifier("Regularized QDA", QuadraticDiscriminantAnalysis(reg_param=best_qda[1]), Xb, yb, Xva, yva, Xte, yte))
    rows.append(eval_classifier("Logistic", make_pipeline(StandardScaler(with_mean=False), LogisticRegression(max_iter=5000, class_weight="balanced")), Xtr, ytr, Xva, yva, Xte, yte))
    rows.append(eval_classifier("RBF-SVM", SVC(C=1, gamma="scale", class_weight="balanced", probability=True), Xtr, ytr, Xva, yva, Xte, yte))
    rows.append(eval_classifier(
        "MLP",
        MLPClassifier(
            hidden_layer_sizes=(64, 32), alpha=1e-4, max_iter=500,
            early_stopping=True, validation_fraction=0.15,
            n_iter_no_change=30, random_state=1,
        ),
        Xb, yb, Xva, yva, Xte, yte,
    ))
    rows.append(eval_classifier("Random forest", RandomForestClassifier(n_estimators=300, class_weight="balanced_subsample", random_state=1, n_jobs=-1, min_samples_leaf=2), Xtr, ytr, Xva, yva, Xte, yte))
    result = pd.DataFrame(rows)
    result.to_csv(RESULTS / "ai4i_real_results.csv", index=False)

    file_hash = hashlib.sha256(data_file.read_bytes()).hexdigest()
    metadata = {
        "dataset": "AI4I 2020 Predictive Maintenance Dataset",
        "source": "UCI Machine Learning Repository",
        "source_url": "https://archive.ics.uci.edu/dataset/601/ai4i+2020+predictive+maintenance+dataset",
        "doi": "10.24432/C5HS5C",
        "license": "CC BY 4.0",
        "sha256": file_hash,
        "raw_shape": list(raw.shape),
        "engineered_shape": list(Xdf.shape),
        "usable_rows": int(len(Xdf)),
        "failure_count": int(y.sum()),
        "failure_rate": float(y.mean()),
        "train_counts": np.bincount(ytr).tolist(),
        "validation_counts": np.bincount(yva).tolist(),
        "test_counts": np.bincount(yte).tolist(),
        "split": "ordered 70/15/15 after removal of the first eight lag rows",
        "covariance_training": "majority class randomly down-sampled to the training failure count with seed 123",
        "selected_cD": cD,
        "selected_cB": cB,
        "selected_threshold": threshold,
        "validation_best_balanced_accuracy": best_val,
        "selected_validation_balanced_accuracy": selected["validation_balanced_accuracy"],
        "validation_positive_class_resolution": positive_resolution,
        "selection_rule": "Among candidates within one positive-class balanced-accuracy resolution of the validation maximum, choose the largest cB and then the smallest cD.",
        "feature_count": int(Xdf.shape[1]),
    }
    (RESULTS / "ai4i_real_metadata.json").write_text(json.dumps(metadata, indent=2), encoding="utf-8")
    pd.DataFrame(fit["hD"], columns=["iteration", "step", "feasibility", "l1_norm"]).to_csv(RESULTS / "ai4i_real_matrix_convergence.csv", index=False)
    pd.DataFrame(fit["hB"], columns=["iteration", "step", "feasibility", "l1_norm"]).to_csv(RESULTS / "ai4i_real_vector_convergence.csv", index=False)
    np.save(RESULTS / "ai4i_real_D.npy", fit["D"])
    return result, fit, tuning


def make_figures(gsum, csum, partition, timing, distributed, application, fit, real_application=None, real_fit=None):
    # Workflow diagram
    fig, ax = plt.subplots(figsize=(11, 3.2))
    ax.axis("off")
    labels = ["Class-wise data", "Sparse QDA equations", "Column feature splitting", "Parallel proximal updates", "Fault score and graph"]
    xs = np.linspace(0.08, 0.92, len(labels))
    for i, (x, label) in enumerate(zip(xs, labels)):
        ax.text(x, 0.5, label, ha="center", va="center", fontsize=10, bbox=dict(boxstyle="round,pad=0.5", fc="white", ec="black"))
        if i < len(labels) - 1:
            ax.annotate("", xy=(xs[i + 1] - 0.09, 0.5), xytext=(x + 0.09, 0.5), arrowprops=dict(arrowstyle="->", lw=1.5))
    fig.tight_layout()
    fig.savefig(FIGURES / "workflow.pdf", bbox_inches="tight")
    fig.savefig(FIGURES / "workflow.png", dpi=220, bbox_inches="tight")
    plt.close(fig)

    # Covariance-only performance
    fig, ax = plt.subplots(figsize=(7.4, 4.2))
    methods = ["MF-FS-SDAR", "QDA", "RBF-SVM", "LDA", "Logistic"]
    for method in methods:
        sub = csum[csum.method == method].sort_values("p")
        ax.plot(sub.p, sub.mean_balanced_accuracy, marker="o", label=method)
    ax.set_xlabel("Dimension p")
    ax.set_ylabel("Mean balanced accuracy")
    ax.set_ylim(0.45, 0.88)
    ax.legend(ncol=2, frameon=False)
    ax.grid(True, alpha=0.25)
    fig.tight_layout()
    fig.savefig(FIGURES / "covariance_only_performance.pdf")
    fig.savefig(FIGURES / "covariance_only_performance.png", dpi=220)
    plt.close(fig)

    # Partition accuracy and speedup
    fig, ax = plt.subplots(figsize=(7.2, 4.1))
    ax.semilogy(partition.K, np.maximum(partition.max_abs_difference, 1e-18), marker="o")
    ax.set_xlabel("Number of column blocks K")
    ax.set_ylabel("Max. iterate difference from K=1")
    ax.grid(True, alpha=0.25)
    fig.tight_layout()
    fig.savefig(FIGURES / "partition_insensitivity.pdf")
    fig.savefig(FIGURES / "partition_insensitivity.png", dpi=220)
    plt.close(fig)

    fig, ax = plt.subplots(figsize=(6.5, 4.0))
    ax.bar(timing.K.astype(str), timing.speedup)
    ax.set_xlabel("Worker blocks K")
    ax.set_ylabel("Single-node speedup")
    ax.axhline(1.0, linewidth=0.8)
    fig.tight_layout()
    fig.savefig(FIGURES / "shared_memory_speedup.pdf")
    fig.savefig(FIGURES / "shared_memory_speedup.png", dpi=220)
    plt.close(fig)

    # Process-based distributed-memory emulation
    fig, ax = plt.subplots(figsize=(7.0, 4.2))
    ax.bar(distributed.K.astype(str), distributed.median_worker_compute_seconds, label="worker computation")
    ax.bar(
        distributed.K.astype(str),
        distributed.median_communication_aggregation_seconds,
        bottom=distributed.median_worker_compute_seconds,
        label="communication, aggregation and scheduling",
    )
    ax.set_xlabel("Worker processes K")
    ax.set_ylabel("Median wall-clock contribution (s)")
    ax.legend(frameon=False, fontsize=8)
    fig.tight_layout()
    fig.savefig(FIGURES / "distributed_process_breakdown.pdf")
    fig.savefig(FIGURES / "distributed_process_breakdown.png", dpi=220)
    plt.close(fig)

    # Application comparison
    fig, ax = plt.subplots(figsize=(9.0, 4.2))
    ordered = application.sort_values("balanced_accuracy", ascending=False)
    ax.bar(ordered.method, ordered.balanced_accuracy)
    ax.set_ylabel("Balanced accuracy")
    ax.set_ylim(0.75, 1.0)
    ax.tick_params(axis="x", rotation=25)
    fig.tight_layout()
    fig.savefig(FIGURES / "digital_twin_balanced_accuracy.pdf")
    fig.savefig(FIGURES / "digital_twin_balanced_accuracy.png", dpi=220)
    plt.close(fig)

    if real_application is not None:
        fig, axes = plt.subplots(1, 2, figsize=(10.0, 4.0))
        ordered = real_application.sort_values("balanced_accuracy", ascending=False)
        axes[0].bar(ordered.method, ordered.balanced_accuracy)
        axes[0].set_ylabel("Balanced accuracy")
        axes[0].set_ylim(0.75, 0.96)
        axes[0].tick_params(axis="x", rotation=55, labelsize=8)
        axes[0].grid(axis="y", alpha=0.25)
        ordered_pr = real_application.sort_values("pr_auc", ascending=False)
        axes[1].bar(ordered_pr.method, ordered_pr.pr_auc)
        axes[1].set_ylabel("PR-AUC")
        axes[1].set_ylim(0.0, 0.82)
        axes[1].tick_params(axis="x", rotation=55, labelsize=8)
        axes[1].grid(axis="y", alpha=0.25)
        fig.suptitle("UCI AI4I predictive-maintenance observations", fontsize=11)
        fig.tight_layout()
        fig.savefig(FIGURES / "ai4i_real_application_performance.pdf")
        fig.savefig(FIGURES / "ai4i_real_application_performance.png", dpi=220)
        plt.close(fig)

    # Convergence plot
    hD = pd.DataFrame(fit["hD"], columns=["iteration", "step", "feasibility", "l1_norm"])
    hB = pd.DataFrame(fit["hB"], columns=["iteration", "step", "feasibility", "l1_norm"])
    fig, ax = plt.subplots(figsize=(7.0, 4.2))
    ax.semilogy(hD.iteration, np.maximum(hD.step, 1e-12), label="matrix step")
    ax.semilogy(hB.iteration, np.maximum(hB.step, 1e-12), label="vector step")
    ax.set_xlabel("Iteration")
    ax.set_ylabel("Successive-iterate residual")
    ax.legend(frameon=False)
    ax.grid(True, alpha=0.25)
    fig.tight_layout()
    fig.savefig(FIGURES / "convergence.pdf")
    fig.savefig(FIGURES / "convergence.png", dpi=220)
    plt.close(fig)

    # Differential graph heatmap
    D = fit["D"]
    fig, ax = plt.subplots(figsize=(5.2, 4.5))
    image = ax.imshow(D, aspect="auto", interpolation="nearest")
    ax.set_xlabel("Feature index")
    ax.set_ylabel("Feature index")
    ax.set_title("Estimated differential precision graph")
    fig.colorbar(image, ax=ax, shrink=0.8)
    fig.tight_layout()
    fig.savefig(FIGURES / "digital_twin_D_heatmap.pdf")
    fig.savefig(FIGURES / "digital_twin_D_heatmap.png", dpi=220)
    plt.close(fig)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--full", action="store_true", help="run all Monte Carlo repetitions and p=700 timing")
    parser.add_argument("--skip-simulations", action="store_true")
    args = parser.parse_args()
    start = time.perf_counter()
    if args.skip_simulations and (RESULTS / "simulation_general_summary.csv").exists():
        gsum = pd.read_csv(RESULTS / "simulation_general_summary.csv")
        csum = pd.read_csv(RESULTS / "simulation_covariance_only_summary.csv")
    else:
        gsum, csum = run_simulations(args.full)
    partition = run_partition_test()
    timing = run_microbenchmark(args.full)
    distributed = run_distributed_benchmark(args.full)
    application, fit = run_digital_twin()
    real_application, real_fit, _ = run_real_ai4i_application()
    run_solver_comparison(args.full)
    run_scale_benchmark(args.full)
    make_figures(gsum, csum, partition, timing, distributed, application, fit, real_application, real_fit)
    print(f"Completed in {time.perf_counter() - start:.1f} seconds")
    print(f"Results: {RESULTS}")
    print(f"Figures: {FIGURES}")


if __name__ == "__main__":
    main()
