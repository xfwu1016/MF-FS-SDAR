# Frozen additional experiment protocol — 24 October 2026

This protocol was written before downloading/evaluating the leukemia test file.
It supplements, rather than replaces, the cached industrial-style results.

## Genuine high-dimensional observations

Golub et al. leukemia gene-expression data, LIBSVM distribution: 38 training
specimens, 34 test specimens, 7,129 expression features. Retain the published
training/test separation. Use stratified three-fold cross-validation (seed 20261024)
within the training set for all hyperparameter selection. Refit on all 38 training
specimens and evaluate the 34 test specimens once after selection.

Within each fitting fold, select the 100 highest ANOVA F-score genes and standardize
with fitting-fold statistics. The final p=100 remains greater than the training
sample size. The supplied files have already undergone instance-wise and global
feature-wise normalization; training-only restandardization algebraically cancels
the earlier feature-wise affine transformation (up to file rounding). Do not claim
that these are raw assay intensities or that this is an external clinical validation.

MF-FS-SDAR and the D-trace classifier use identical classwise Ledoit–Wolf covariance
estimates, means, beta Dantzig estimates, score construction and class priors. This
is a shrinkage-covariance application variant; the inherited sample-covariance
statistical theory is not asserted to transfer without additional assumptions.
D-trace replaces only D estimation with Yuan et al.'s Lasso-penalized D-trace loss;
we implement accelerated proximal gradient, not the authors' original ADM solver.
For both methods c_D,c_beta are selected from {0.25,0.5,1,2} using the highest
mean inner-fold balanced accuracy, breaking ties by larger c_D then larger c_beta.
Use the natural zero threshold including training class priors, with no test-based
threshold tuning. PPA uses mu=1/Lbar, eta=1.01*Lbar with a certified spectral norm
upper bound. Maximum 20,000 iterations; stopping diagnostics are recorded even
when the cap is reached. D-trace uses the same upper bound as its gradient
Lipschitz bound and a normalized proximal-gradient residual tolerance 1e-6.

Baselines on the same selected genes: shrinkage LDA; QDA covariance shrinkage in
{0.1,0.3,0.5,0.9}; logistic C in {0.1,1,10}; RBF-SVM C in {0.1,1,10} with
gamma='scale'; MLP (64,32), lbfgs, alpha in {1e-4,1e-2}, max_iter=2000;
random forest 300 trees, max_depth in {3,None}, min_samples_leaf in {1,3}.
Use class balancing where supported; retain all training observations.
Report balanced accuracy, precision, recall, F1, ROC-AUC, average precision
(reported as AP, not trapezoidal PR-AUC), confusion counts, fit time and diagnostic
status. Runtime excludes cross-validation and is not an estimator-quality ranking.

## Direct differential-precision comparison with known truth

Use the existing covariance-only generator at p=40 and p=80, n1=n2=100,
five independent seeds (20261024 + replication). Train/validation draws are
independent. Compare the Dantzig estimator and D-trace estimator with identical
sample covariances. Select c in {0.25,0.5,1,2} by held-out D-trace loss on a
separate validation sample of 100 observations per class, never by true-network
error. Report relative Frobenius error, off-diagonal support F1 at |D_ij|>1e-4,
fit time, selected c and solver diagnostics for every replicate. Keep all runs.
This is a comparison of different estimators, not matched-objective solver speed.

Compatibility note, before test access: scikit-learn 1.9 rejects its default SVD
QDA solver for p greater than the class sample size, even with reg_param. Use its
eigen solver and shrinkage parameter with the same four numerical settings.

Do not change this protocol after inspecting test outcomes to improve rankings.
