# Fixed-parameter numerical accuracy follow-up

After the prespecified leukemia evaluation, the selected matrix PPA fit had
reached 20,000 iterations with feasibility violation 0.05535 and normalized
objective difference 0.02205. The primary result is retained unchanged.
One additional run increases only the iteration cap to 200,000, holding the data,
screening, covariance estimates, c_D=0.25, c_beta=0.5, prior, threshold and stopping
tolerances fixed. Both numerical diagnostics and predictions are reported,
regardless of their direction of change. This is a numerical-accuracy sensitivity
check initiated after test access, not a new test-blind tuning run.
