# Reproducibility code

## October 2026 revision additions

From the package root, in an environment matching requirements_revision22.txt:

    python code/run_revision22.py --mode test
    python code/run_revision22.py --mode all
    python code/run_revision22.py --mode refine
    python code/verify_cached_revision22.py

The first command checks analytic diagonal cases and the D-trace gradient.
The second runs the frozen genuine-data and direct-estimator protocols.
The third is a separately disclosed fixed-parameter numerical-accuracy follow-up.
The last verifies source/protocol hashes and recomputes cached summary metrics.
See revision22_protocol.md and accuracy_followup.md. Cached CSV/JSON diagnostics
retain all iteration-cap cases; neither the primary nor refined leukemia matrix
PPA fit met all stopping tolerances. Model selection does not use test scores.
The older AI4I grid was expanded after earlier test outcomes were known and is
therefore exploratory despite using validation scores in the selection rule.

The experiment groups use the execution environments described below.
The added experiments record their actual software and BLAS configuration in
results/leukemia_metadata.json. Do not compare times across separate environments.

Public repository: https://github.com/xfwu1016/MF-FS-SDAR

Run the compact verification suite:

```bash
python run_experiments.py
```

Run the full Monte Carlo, shared-memory and process-based distributed-memory experiments:

```bash
python run_experiments.py --full
```

The script writes CSV tables to `../results` and publication figures to `../figures`. The process-based distributed-memory benchmark uses separate operating-system processes on one host and should not be interpreted as a multi-node cluster benchmark.

The script reports two distinct predictive-maintenance analyses: an **AI4I-inspired synthetic benchmark** generated from documented failure mechanisms, and an application to the released UCI AI4I dataset in `../data/ai4i2020.csv`. The UCI file is included under CC BY 4.0; its source URL, DOI and SHA-256 hash are recorded in `../data/README.md`. The manuscript does not describe either data source as operational plant measurements.

The full run additionally writes `ai4i_real_results.csv`, `ai4i_real_tuning_grid.csv`, `ai4i_real_metadata.json`, the released-data convergence histories and `ai4i_real_D.npy`, together with `solver_comparison.csv`, `alternative_solver_comparison.csv`, `scale_benchmark.csv` and `ai4i_real_application_performance.pdf`/`.png`.

Random seeds, tuning grids, splits and preprocessing are fixed in the script. For the released-data application, the complete $11\times9$ grid is evaluated on validation; candidates within one positive-class balanced-accuracy resolution of the validation maximum are retained, and the largest $c_\beta$ followed by the smallest $c_D$ is selected. Timing values remain hardware dependent. `solver_comparison.csv` is a representation-matched check of explicit-Kronecker and matrix-free PPA implementations. `alternative_solver_comparison.csv` compares matrix-free PPA with the Chambolle--Pock primal-dual hybrid gradient (PDHG) method on the same matrix Dantzig instances, using common feasibility and normalised primal--dual objective-difference stopping criteria. The explicit Kronecker method is used only at small dimensions and is not called by the matrix-free application.

## Reference execution environment

The original reported experiments were run on an AMD Ryzen 9 7950X 16-core processor (4.50 GHz) with 32 GB of memory. The software stack used Python 3.11 together with the package requirements listed in `requirements.txt`. Shared-memory tests use `ThreadPoolExecutor`; the process-based distributed-memory emulation uses `ProcessPoolExecutor` and restricts BLAS to one thread per worker through `threadpoolctl`. The added cached PPA--PDHG timing comparison was measured separately on an AMD Ryzen 7 5800H with Python 3.12.14, NumPy 2.3.5 and one BLAS thread; rerunning the script overwrites these timings with measurements from the local machine.

## Metric labels

AP denotes average precision. Historical CSV fields named `pr_auc` contain
average-precision values, not trapezoidal precision-recall area. These field names
are retained for compatibility; manuscript, supplement and figure labels use AP.
The label-only rendering utility is `code/render_ai4i_figure.py`; it reads the
cached result table without fitting models or changing numerical results.
