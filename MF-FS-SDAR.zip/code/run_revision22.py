"""Additional, protocol-frozen real-data and differential-network experiments."""
from __future__ import annotations
import argparse, hashlib, json, math, platform, time, urllib.request, warnings
from pathlib import Path
import numpy as np
import pandas as pd
import scipy
import sklearn
from numpy.linalg import norm
from sklearn.datasets import load_svmlight_file
from sklearn.covariance import LedoitWolf
from sklearn.feature_selection import f_classif
from sklearn.model_selection import StratifiedKFold
from sklearn.preprocessing import StandardScaler
from sklearn.discriminant_analysis import LinearDiscriminantAnalysis, QuadraticDiscriminantAnalysis
from sklearn.linear_model import LogisticRegression
from sklearn.neural_network import MLPClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.svm import SVC
from sklearn.metrics import balanced_accuracy_score, precision_score, recall_score, f1_score, roc_auc_score, average_precision_score, confusion_matrix
from threadpoolctl import threadpool_limits, threadpool_info
from run_experiments import soft, op_L, sdar_score, make_cov_only_model, sample_data

ROOT=Path(__file__).resolve().parents[1]
DATA=ROOT/'data'; OUT=ROOT/'results'
GRID=(0.25,0.5,1.0,2.0)
SEED=20261024

def fetch(name):
    path=DATA/name
    if not path.exists():
        url='https://www.csie.ntu.edu.tw/~cjlin/libsvmtools/datasets/binary/'+name
        blob=urllib.request.urlopen(url,timeout=90).read()
        path.write_bytes(blob)
    return path

def ppa(A,b,lam,Lbar,cap=20000):
    """Generic exact matrix/vector PPA, certified eta > mu ||A||^2."""
    x=np.zeros_like(b); z=x.copy(); u=x.copy(); rprev=-b.copy()
    mu=1/max(Lbar,1e-12); eta=1.01*max(Lbar,1e-12)
    start=time.perf_counter()
    for it in range(1,cap+1):
        xn=soft(x+A(u)/eta,1/eta)
        zn=np.clip(z-u/mu,-lam,lam)
        ax=A(xn); r=ax-zn-b
        un=u-mu/2*(2*r-rprev)
        step=math.sqrt(np.sum((xn-x)**2)+np.sum((zn-z)**2)+np.sum((un-u)**2))
        x,z,u,rprev=xn,zn,un,r
        if it%20==0:
            feas=max(0.,float(np.max(np.abs(ax-b)))-lam)
            v=-u; vf=v/max(1.,float(np.max(np.abs(A(v)))))
            primal=float(np.sum(abs(x)))
            dual=-float(np.sum(vf*b))-lam*float(np.sum(abs(vf)))
            gap=abs(primal-dual)/max(1.,primal,abs(dual))
            if feas<=5e-4 and gap<=1e-3:
                break
    return x,dict(iterations=it,seconds=time.perf_counter()-start,feasibility=feas,
                  relative_objective_difference=gap,step=step,converged=bool(feas<=5e-4 and gap<=1e-3),mu=mu,eta=eta)

def dtrace(S1,S2,lam,cap=20000):
    """Yuan et al. loss, matrix-free FISTA; diagnostic is gradient mapping."""
    B=S1-S2; Lbar=norm(S1,2)*norm(S2,2)
    D=np.zeros_like(B); Y=D.copy(); t=1.; start=time.perf_counter()
    for it in range(1,cap+1):
        Dn=soft(Y-(op_L(Y,S1,S2)-B)/Lbar,lam/Lbar)
        tn=(1+math.sqrt(1+4*t*t))/2
        Y=Dn+(t-1)/tn*(Dn-D)
        D,t=Dn,tn
        if it%20==0:
            mapping=Lbar*(D-soft(D-(op_L(D,S1,S2)-B)/Lbar,lam/Lbar))
            residual=norm(mapping)/max(1.,norm(B),norm(D))
            if residual<=1e-6: break
    return D,dict(iterations=it,seconds=time.perf_counter()-start,proximal_gradient_residual=residual,
                  converged=bool(residual<=1e-6),lipschitz_upper_bound=Lbar)

def summaries(X,y,shrink=True):
    groups=[X[y==c] for c in (0,1)]
    means=[g.mean(0) for g in groups]
    covs=[LedoitWolf().fit(g).covariance_ if shrink else np.cov(g,rowvar=False,bias=True) for g in groups]
    return means,covs,min(map(len,groups))

def preprocess(X,y,Z):
    # ANOVA score is invariant to the supplied per-feature affine normalization.
    scores=np.nan_to_num(f_classif(X,y)[0],nan=-np.inf)
    cols=np.argsort(-scores,kind='stable')[:100]
    scaler=StandardScaler().fit(X[:,cols])
    return scaler.transform(X[:,cols]),scaler.transform(Z[:,cols]),cols

def family_scores(X,y,Z):
    means,(S1,S2),n=summaries(X,y)
    scale=math.sqrt(math.log(X.shape[1])/n)
    B=S1-S2; bound=norm(S1,2)*norm(S2,2)
    fits={}; ds={}; bs={}
    for c in GRID:
        ds['MF-FS-SDAR',c]=ppa(lambda D:op_L(D,S1,S2),B,c*scale,bound)
        ds['D-trace',c]=dtrace(S1,S2,c*scale)
        bs[c]=ppa(lambda b:S2@b,means[1]-means[0],c*scale,norm(S2,2))
    for method in ('MF-FS-SDAR','D-trace'):
        for cD in GRID:
            for cB in GRID:
                D,diagD=ds[method,cD]; beta,diagB=bs[cB]
                fit=dict(D=(D+D.T)/2,beta=beta,m1=means[0],m2=means[1],S1=S1)
                score=-sdar_score(fit,Z)-2*math.log(np.sum(y==0)/np.sum(y==1))
                fits[method,cD,cB]=(score,fit,diagD,diagB)
    return fits

def baseline_specs():
    specs=[('Shrinkage LDA',{},lambda:LinearDiscriminantAnalysis(solver='lsqr',shrinkage='auto'))]
    for v in (.1,.3,.5,.9): specs.append(('Regularised QDA',{'shrinkage':v},lambda v=v:QuadraticDiscriminantAnalysis(solver='eigen',shrinkage=v)))
    for v in (.1,1.,10.):
        specs.append(('Logistic',{'C':v},lambda v=v:LogisticRegression(C=v,class_weight='balanced',max_iter=2000)))
        specs.append(('RBF-SVM',{'C':v},lambda v=v:SVC(C=v,gamma='scale',class_weight='balanced')))
    for v in (1e-4,1e-2): specs.append(('MLP',{'alpha':v},lambda v=v:MLPClassifier(hidden_layer_sizes=(64,32),solver='lbfgs',alpha=v,max_iter=2000,random_state=SEED)))
    for depth in (3,None):
        for leaf in (1,3): specs.append(('Random forest',{'max_depth':depth,'min_samples_leaf':leaf},lambda d=depth,l=leaf:RandomForestClassifier(n_estimators=300,max_depth=d,min_samples_leaf=l,class_weight='balanced',random_state=SEED,n_jobs=1)))
    return specs

def metrics(y,pred,score):
    tn,fp,fn,tp=confusion_matrix(y,pred,labels=[0,1]).ravel()
    return dict(balanced_accuracy=balanced_accuracy_score(y,pred),precision=precision_score(y,pred,zero_division=0),
                recall=recall_score(y,pred),f1=f1_score(y,pred),roc_auc=roc_auc_score(y,score),
                average_precision=average_precision_score(y,score),tn=int(tn),fp=int(fp),fn=int(fn),tp=int(tp))

def leukemia():
    # The test file is deliberately fetched/read only AFTER parameter selection.
    path=fetch('leu.bz2')
    X,labels=load_svmlight_file(str(path),n_features=7129); X=X.toarray(); y=(labels>0).astype(int)
    folds=list(StratifiedKFold(3,shuffle=True,random_state=SEED).split(X,y))
    rows=[]; specs=baseline_specs()
    for fold,(train,valid) in enumerate(folds):
        Xt,Xv,_=preprocess(X[train],y[train],X[valid])
        print('leukemia inner fold',fold+1,flush=True)
        for (method,cD,cB),(score,_,dd,db) in family_scores(Xt,y[train],Xv).items():
            rows.append(dict(fold=fold,method=method,key=json.dumps([cD,cB]),balanced_accuracy=balanced_accuracy_score(y[valid],score>=0),D_converged=dd['converged'],beta_converged=db['converged']))
        for idx,(method,config,build) in enumerate(specs):
            model=build().fit(Xt,y[train]); pred=model.predict(Xv)
            rows.append(dict(fold=fold,method=method,key=str(idx),balanced_accuracy=balanced_accuracy_score(y[valid],pred)))
    cv=pd.DataFrame(rows); cv.to_csv(OUT/'leukemia_inner_cv.csv',index=False)
    selected={}
    for method in cv.method.unique():
        mean=cv[cv.method==method].groupby('key').balanced_accuracy.mean()
        if method in ('MF-FS-SDAR','D-trace'):
            key=max(mean.index,key=lambda k:(round(float(mean[k]),12),*json.loads(k)))
        else: key=max(mean.index,key=lambda k:(round(float(mean[k]),12),-int(k)))
        selected[method]=dict(key=key,inner_balanced_accuracy=float(mean[key]))
    (OUT/'leukemia_selection_before_test.json').write_text(json.dumps(selected,indent=2),encoding='utf-8')
    # Test outcomes cannot affect selections saved above.
    testpath=fetch('leu.t.bz2')
    Z,testlabels=load_svmlight_file(str(testpath),n_features=7129); Z=Z.toarray(); yt=(testlabels>0).astype(int)
    Xt,Zt,cols=preprocess(X,y,Z)
    # Fit only the selected pairs (no test evaluation of the tuning grid).
    means,(S1,S2),n=summaries(Xt,y); scale=math.sqrt(math.log(100)/n)
    results=[]; predictions=[]; diagnostics={}
    for method,choice in selected.items():
        if method in ('MF-FS-SDAR','D-trace'):
            cD,cB=json.loads(choice['key']); start=time.perf_counter()
            if method=='MF-FS-SDAR': D,dd=ppa(lambda d:op_L(d,S1,S2),S1-S2,cD*scale,norm(S1,2)*norm(S2,2))
            else: D,dd=dtrace(S1,S2,cD*scale)
            beta,db=ppa(lambda b:S2@b,means[1]-means[0],cB*scale,norm(S2,2))
            elapsed=time.perf_counter()-start
            fit=dict(D=(D+D.T)/2,beta=beta,m1=means[0],m2=means[1],S1=S1)
            score=-sdar_score(fit,Zt)-2*math.log(np.sum(y==0)/np.sum(y==1)); pred=(score>=0).astype(int)
            diagnostics[method]=dict(D=dd,beta=db,cD=cD,cB=cB)
            np.savez(OUT/('leukemia_'+('mf' if method=='MF-FS-SDAR' else 'dtrace')+'_fit.npz'),**fit,selected_columns=cols)
        else:
            _,config,build=specs[int(choice['key'])]; start=time.perf_counter(); model=build().fit(Xt,y)
            elapsed=time.perf_counter()-start; pred=model.predict(Zt)
            score=model.decision_function(Zt) if hasattr(model,'decision_function') else model.predict_proba(Zt)[:,1]
            diagnostics[method]=config
        results.append(dict(method=method,**metrics(yt,pred,score),fit_seconds=elapsed,**choice))
        predictions.extend(dict(method=method,index=i,label=int(yt[i]),prediction=int(pred[i]),score=float(score[i])) for i in range(len(yt)))
    pd.DataFrame(results).to_csv(OUT/'leukemia_test_results.csv',index=False)
    pd.DataFrame(predictions).to_csv(OUT/'leukemia_test_predictions.csv',index=False)
    meta=dict(seed=SEED,n_train=len(y),n_test=len(yt),original_p=7129,selected_p=100,
              train_class_counts=np.bincount(y).tolist(),test_class_counts=np.bincount(yt).tolist(),
              source='https://www.csie.ntu.edu.tw/~cjlin/libsvmtools/datasets/binary.html#leukemia',
              sha256={f.name:hashlib.sha256(f.read_bytes()).hexdigest() for f in (path,testpath)},
              protocol_sha256=hashlib.sha256((ROOT/'code/revision22_protocol.md').read_bytes()).hexdigest(),
              diagnostics=diagnostics,selected_columns_zero_based=cols.tolist(),python=platform.python_version(),
              numpy=np.__version__,scipy=scipy.__version__,sklearn=sklearn.__version__,platform=platform.platform(),blas=threadpool_info())
    (OUT/'leukemia_metadata.json').write_text(json.dumps(meta,indent=2),encoding='utf-8')
    print(pd.DataFrame(results).to_string(index=False),flush=True)

def network():
    rows=[]; grid=[]
    for p in (40,80):
        for rep in range(5):
            seed=SEED+rep; model=make_cov_only_model(p,seed)
            X1,X2=sample_data(100,100,model,seed+100); V1,V2=sample_data(100,100,model,seed+200)
            S1,S2=[np.cov(x,rowvar=False,bias=True) for x in (X1,X2)]
            V1,V2=[np.cov(x,rowvar=False,bias=True) for x in (V1,V2)]
            truth=model[4]; scale=math.sqrt(math.log(p)/100)
            for method in ('MF-FS-SDAR','D-trace'):
                candidates=[]
                for c in GRID:
                    if method=='MF-FS-SDAR': D,diag=ppa(lambda d:op_L(d,S1,S2),S1-S2,c*scale,norm(S1,2)*norm(S2,2))
                    else: D,diag=dtrace(S1,S2,c*scale)
                    loss=float(.5*np.sum(D*op_L(D,V1,V2))-np.sum(D*(V1-V2)))
                    candidates.append((loss,-c,D,diag))
                    grid.append(dict(p=p,replicate=rep,method=method,c=c,validation_loss=loss,**diag))
                loss,negc,D,diag=min(candidates,key=lambda z:(z[0],z[1]))
                upper=np.triu_indices(p,1)
                support=f1_score(abs(truth[upper])>1e-4,abs(D[upper])>1e-4,zero_division=0)
                rows.append(dict(p=p,replicate=rep,method=method,c=-negc,relative_frobenius=norm(D-truth)/norm(truth),support_f1=support,**diag))
            print('network',p,rep,flush=True)
            pd.DataFrame(rows).to_csv(OUT/'differential_network_raw.csv',index=False)
    pd.DataFrame(grid).to_csv(OUT/'differential_network_grid.csv',index=False)
    df=pd.DataFrame(rows); summary=df.groupby(['p','method']).agg(
        frobenius_mean=('relative_frobenius','mean'),frobenius_sd=('relative_frobenius','std'),
        f1_mean=('support_f1','mean'),f1_sd=('support_f1','std'),seconds_mean=('seconds','mean'),
        converged_count=('converged','sum')).reset_index()
    summary.to_csv(OUT/'differential_network_summary.csv',index=False)
    print(summary.to_string(index=False),flush=True)

def selftest():
    a=np.array([1.,2.,3.]); b=np.array([2.,3.,4.]); S1=np.diag(a); S2=np.diag(b); lam=.1
    D,diag=dtrace(S1,S2,lam)
    expected=np.diag(soft(a-b,lam)/(a*b))
    assert np.max(abs(D-expected))<1e-5,(D,expected)
    P,diagp=ppa(lambda d:op_L(d,S1,S2),S1-S2,lam,norm(S1,2)*norm(S2,2))
    assert np.max(abs(P-expected))<1e-3
    assert diagp['converged'] and diag['converged']
    rng=np.random.default_rng(SEED); X=rng.normal(size=(3,3)); E=rng.normal(size=(3,3)); h=1e-6
    loss=lambda Z:.5*np.sum(Z*op_L(Z,S1,S2))-np.sum(Z*(S1-S2))
    numerical=(loss(X+h*E)-loss(X-h*E))/(2*h)
    assert abs(numerical-np.sum((op_L(X,S1,S2)-(S1-S2))*E))<1e-6
    print('Diagonal analytical solutions and D-trace gradient checks passed.',flush=True)

def refine():
    """Accuracy sensitivity, fixed selected parameters; retain primary 20k result."""
    X,lab=load_svmlight_file(str(DATA/'leu.bz2'),n_features=7129)
    Z,tlab=load_svmlight_file(str(DATA/'leu.t.bz2'),n_features=7129)
    y=(lab>0).astype(int); yt=(tlab>0).astype(int)
    Xt,Zt,cols=preprocess(X.toarray(),y,Z.toarray())
    means,(S1,S2),n=summaries(Xt,y)
    chosen=json.loads((OUT/'leukemia_selection_before_test.json').read_text())
    cD,cB=json.loads(chosen['MF-FS-SDAR']['key']);scale=math.sqrt(math.log(100)/n)
    D,dd=ppa(lambda d:op_L(d,S1,S2),S1-S2,cD*scale,norm(S1,2)*norm(S2,2),cap=200000)
    beta,db=ppa(lambda b:S2@b,means[1]-means[0],cB*scale,norm(S2,2),cap=200000)
    fit=dict(D=(D+D.T)/2,beta=beta,m1=means[0],m2=means[1],S1=S1)
    score=-sdar_score(fit,Zt)-2*math.log(np.sum(y==0)/np.sum(y==1));pred=(score>=0).astype(int)
    result=dict(method='MF-FS-SDAR accuracy refinement',**metrics(yt,pred,score),D=dd,beta=db,cD=cD,cB=cB)
    (OUT/'leukemia_accuracy_refinement.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
    np.savez(OUT/'leukemia_mf_refined_fit.npz',**fit,selected_columns=cols)
    pd.DataFrame(dict(label=yt,prediction=pred,score=score)).to_csv(OUT/'leukemia_refined_predictions.csv',index=False)
    print(json.dumps(result,indent=2),flush=True)

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--mode',choices=['all','test','leukemia','network','refine'],default='all');args=parser.parse_args()
    with warnings.catch_warnings(record=True) as caught, threadpool_limits(limits=1):
        warnings.simplefilter('always'); selftest()
        if args.mode in ('all','leukemia'): leukemia()
        if args.mode in ('all','network'): network()
        if args.mode=='refine': refine()
        (OUT/('revision22_'+args.mode+'_warnings.txt')).write_text('\n'.join(sorted({str(w.message) for w in caught})),encoding='utf-8')
