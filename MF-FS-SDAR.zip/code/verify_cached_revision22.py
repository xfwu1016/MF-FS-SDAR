"""Verify cached metrics and provenance without fitting or changing results."""
from pathlib import Path
import hashlib,json
import numpy as np
import pandas as pd
from sklearn.metrics import (balanced_accuracy_score,precision_score,recall_score,
    f1_score,roc_auc_score,average_precision_score,confusion_matrix)

root=Path(__file__).resolve().parents[1]
results=root/"results"
meta=json.loads((results/"leukemia_metadata.json").read_text())
for name,expected in meta["sha256"].items():
    assert hashlib.sha256((root/"data"/name).read_bytes()).hexdigest()==expected,name
assert hashlib.sha256((root/"code/revision22_protocol.md").read_bytes()).hexdigest()==meta["protocol_sha256"]
pred=pd.read_csv(results/"leukemia_test_predictions.csv")
table=pd.read_csv(results/"leukemia_test_results.csv")
metrics={"balanced_accuracy":balanced_accuracy_score,"precision":precision_score,
         "recall":recall_score,"f1":f1_score,"roc_auc":roc_auc_score,
         "average_precision":average_precision_score}
for _,row in table.iterrows():
    p=pred[pred.method==row["method"]].sort_values("index")
    assert len(p)==34 and p["index"].nunique()==34
    for name,fn in metrics.items():
        value=fn(p.label,p.score if name in ("roc_auc","average_precision") else p.prediction)
        assert np.isclose(value,row[name],atol=1e-12), (row["method"],name)
    assert np.array_equal(confusion_matrix(p.label,p.prediction,labels=[0,1]).ravel(),
                          row[["tn","fp","fn","tp"]].to_numpy(dtype=int))
raw=pd.read_csv(results/"differential_network_raw.csv")
summary=pd.read_csv(results/"differential_network_summary.csv")
for _,row in summary.iterrows():
    group=raw[(raw.p==row.p)&(raw.method==row.method)]
    assert len(group)==5
    for field,rawfield in (("frobenius","relative_frobenius"),("f1","support_f1")):
        assert np.isclose(group[rawfield].mean(),row[field+"_mean"])
        assert np.isclose(group[rawfield].std(ddof=1),row[field+"_sd"])
    assert np.isclose(group.seconds.mean(),row.seconds_mean)
    assert group.converged.sum()==row.converged_count
print("Verified source/protocol hashes, all eight leukemia metric rows and four network summaries.")
