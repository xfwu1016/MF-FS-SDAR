"""Render the cached AI4I comparison with the correct average-precision label.

Only presentation is updated; no estimation, tuning or result-table write occurs.
The legacy pr_auc column contains sklearn average_precision_score values.
"""
from pathlib import Path
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import pandas as pd

root = Path(__file__).resolve().parents[1]
data = pd.read_csv(root / "results/ai4i_real_results.csv")
fig, axes = plt.subplots(1, 2, figsize=(10.0, 4.0))
ordered = data.sort_values("balanced_accuracy", ascending=False)
axes[0].bar(ordered.method, ordered.balanced_accuracy)
axes[0].set_ylabel("Balanced accuracy")
axes[0].set_ylim(0.75, 0.96)
axes[0].tick_params(axis="x", rotation=55, labelsize=8)
axes[0].grid(axis="y", alpha=0.25)
ordered_ap = data.sort_values("pr_auc", ascending=False)
axes[1].bar(ordered_ap.method, ordered_ap.pr_auc)
axes[1].set_ylabel("Average precision (AP)")
axes[1].set_ylim(0.0, 0.82)
axes[1].tick_params(axis="x", rotation=55, labelsize=8)
axes[1].grid(axis="y", alpha=0.25)
fig.suptitle("UCI AI4I predictive-maintenance observations", fontsize=11)
fig.tight_layout()
fig.savefig(root / "figures/ai4i_real_application_performance.pdf")
fig.savefig(root / "figures/ai4i_real_application_performance.png", dpi=220)
plt.close(fig)
