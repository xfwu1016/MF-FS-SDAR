# MF-FS-SDAR reproducibility material — Revision 26

Repository: https://github.com/xfwu1016/MF-FS-SDAR

This archive contains the code, data sources/copies, cached results, figures and
supplement PDF/LaTeX for the manuscript revision. It excludes correspondence and
private submission documents. Extract its directories into the repository root,
or upload this archive as the replacement code-data-result.zip.

## Reproduce

Use Python 3.12.14 and the environment recorded in code/requirements_revision22.txt:

    python code/run_revision22.py --mode test
    python code/run_revision22.py --mode all
    python code/run_revision22.py --mode refine
    python code/verify_cached_revision22.py

The cached results preserve every selected fit, including iteration-cap cases.
See code/revision22_protocol.md and code/accuracy_followup.md. The leukemia matrix
PPA does not meet all tolerances at either cap; its predictive metrics must not
be presented as those of a certified exact optimum. The older AI4I comparison is
exploratory following expansion of its grid after preliminary test evaluation.
Historical runs use code/run_experiments.py and code/requirements.txt; their
hardware-dependent times belong to separately reported experiments.

## Data provenance

AI4I is a released synthetic industrial-style benchmark under CC BY 4.0.
Leukemia contains measured gene expression from the Golub et al. benchmark,
distributed in LIBSVM with a fixed 38/34 train/test split. The downloaded features
are preprocessed, not raw assays. See data/README.md for sources and checksums.
The LIBSVM source does not specify a separate dataset reuse licence; check its
terms before public redistribution. The included copies do not imply a new
unrestricted licence. The script supports downloading from the original source.

AP denotes average precision. Historical pr_auc CSV fields contain AP values;
their names are retained for compatibility. Updated manuscript and plot labels
use AP. Run python code/render_ai4i_figure.py to regenerate the cached AI4I plot
without refitting models or changing numerical results.

The supplementary document is supplement/supplement.pdf, with its LaTeX source.
MANIFEST.sha256 lists every supplied file and its checksum.
