# AI4I 2020 data

`ai4i2020.csv` is the released AI4I 2020 Predictive Maintenance Dataset obtained
from the UCI Machine Learning Repository (dataset 601).

- Source: https://archive.ics.uci.edu/dataset/601/ai4i+2020+predictive+maintenance+dataset
- Dataset DOI: https://doi.org/10.24432/C5HS5C
- License: Creative Commons Attribution 4.0 International (CC BY 4.0)
- SHA-256: `DC6630CD9B1F0F853922FAD78A1B6436570D3F1EC863F1DD5C4340AC56BC8A8E`

The file is included for reproducibility under the stated license. The dataset
itself is a synthetic industrial-style benchmark released by UCI; in the paper
we refer to this analysis as the application to the released UCI observations,
not as operational plant data.

## Measured leukemia gene-expression data

The LIBSVM collection distributes the Golub et al. (Science, 1999) leukemia
benchmark at:
https://www.csie.ntu.edu.tw/~cjlin/libsvmtools/datasets/binary.html#leukemia

Files downloaded on 24 October 2026:

- leu.bz2: 38 training specimens, 7,129 features.
  https://www.csie.ntu.edu.tw/~cjlin/libsvmtools/datasets/binary/leu.bz2
  SHA-256: 2f7dc1c8ea4343b17038e27ff777dad0a87d79a5fa29de54765055cc841cb75b
- leu.t.bz2: 34 test specimens, the same features.
  https://www.csie.ntu.edu.tw/~cjlin/libsvmtools/datasets/binary/leu.t.bz2
  SHA-256: 582161e3d5112f6c1604d262413acca5e33cad1b3f522c681faeb369e8b4a271

These are measured expression data, not simulated observations. The distributed
files are already instance-wise and feature-wise normalised; they are not raw
assay intensities. The collection states that the feature scaling used the merged
training/test data. Our subsequent fitting-fold standardisation algebraically
cancels this affine feature scaling, up to file rounding. Gene screening,
covariance shrinkage and parameter selection are performed within training folds.
The released split is retained.

The LIBSVM data page does not state a separate reuse licence for this dataset.
These source copies are included for manuscript reproducibility with attribution;
no new licence is asserted over the original observations. Check applicable source
terms before public redistribution. The script can also download the source files.
